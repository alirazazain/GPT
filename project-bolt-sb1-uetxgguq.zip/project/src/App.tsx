import React, { useState } from 'react';
import { Menu, Settings, Check, Loader2 } from 'lucide-react';
import Sidebar from './components/Sidebar';
import ValidateModule from './modules/ValidateModule';
import SettingsModule from './modules/SettingsModule';
import { SettingsProvider } from './context/SettingsContext';
import './App.css';

function App() {
  const [activeModule, setActiveModule] = useState<'validate' | 'settings'>('validate');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <SettingsProvider>
      <div className="flex h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-200">
        {/* Mobile header */}
        <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-white dark:bg-gray-800 shadow-sm z-10 flex items-center px-4">
          <button
            onClick={toggleSidebar}
            className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            aria-label="Toggle sidebar"
          >
            <Menu size={24} />
          </button>
          <h1 className="ml-4 text-xl font-semibold">MCQ Validator</h1>
        </div>

        {/* Sidebar */}
        <Sidebar 
          activeModule={activeModule} 
          setActiveModule={setActiveModule}
          isSidebarOpen={isSidebarOpen}
          setIsSidebarOpen={setIsSidebarOpen}
        />

        {/* Main content */}
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <div className="container mx-auto px-4 py-6 max-w-4xl">
            {activeModule === 'validate' && <ValidateModule />}
            {activeModule === 'settings' && <SettingsModule />}
          </div>
        </main>
      </div>
    </SettingsProvider>
  );
}

export default App;