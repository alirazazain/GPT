import { formatPrompt } from '../utils/promptFormatter';

interface GeminiError extends Error {
  status?: number;
  details?: string;
}

export async function validateMCQ(
  apiKey: string, 
  systemPrompt: string, 
  userMessageTemplate: string, 
  questionContent: string
): Promise<string> {
  const formattedUserMessage = formatPrompt(userMessageTemplate, questionContent);
  
  const payload = {
    contents: [
      {
        role: "user",
        parts: [
          { text: systemPrompt },
          { text: formattedUserMessage }
        ]
      }
    ],
    generationConfig: {
      temperature: 0,
      maxOutputTokens: 2048,
      topP: 1,
      topK: 1
    },
    safetySettings: [
      {
        category: "HARM_CATEGORY_HARASSMENT",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        category: "HARM_CATEGORY_HATE_SPEECH",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        category: "HARM_CATEGORY_DANGEROUS_CONTENT",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      }
    ]
  };

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(60000), // 60 second timeout
      }
    );

    if (!response.ok) {
      const errorData = await response.json();
      const error = new Error() as GeminiError;
      error.message = errorData.error?.message || `API request failed with status ${response.status}`;
      error.status = response.status;
      error.details = JSON.stringify(errorData);
      throw error;
    }

    const data = await response.json();
    
    if (data.candidates && data.candidates.length > 0 && data.candidates[0].content) {
      return data.candidates[0].content.parts[0].text;
    } else {
      throw new Error('No valid response received from Gemini API');
    }
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        throw new Error('Request timed out. Please try again.');
      }
      throw error;
    }
    throw new Error('An unknown error occurred');
  }
}