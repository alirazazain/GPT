import React, { createContext, useContext, useState, useEffect } from 'react';

interface SettingsContextType {
  apiKey: string;
  setApiKey: (key: string) => void;
  systemPrompt: string;
  setSystemPrompt: (prompt: string) => void;
  userMessageTemplate: string;
  setUserMessageTemplate: (template: string) => void;
  saveSettings: () => void;
  settingsSaved: boolean;
}

const defaultSystemPrompt = 
  'You are a certified academic reviewer. Your task is to validate the following MCQ and determine if the answer and explanation are logically and factually correct.';

const defaultUserMessageTemplate = 
  'Here is the Question Block:\n\n{question}\n\nPlease validate if the marked answer is correct. If it\'s incorrect, explain why and provide the correct answer.';

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [apiKey, setApiKey] = useState('');
  const [systemPrompt, setSystemPrompt] = useState(defaultSystemPrompt);
  const [userMessageTemplate, setUserMessageTemplate] = useState(defaultUserMessageTemplate);
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Load settings from localStorage on initial render
  useEffect(() => {
    const savedApiKey = localStorage.getItem('gemini-api-key');
    const savedSystemPrompt = localStorage.getItem('gemini-system-prompt');
    const savedUserMessageTemplate = localStorage.getItem('gemini-user-message-template');

    if (savedApiKey) setApiKey(savedApiKey);
    if (savedSystemPrompt) setSystemPrompt(savedSystemPrompt);
    if (savedUserMessageTemplate) setUserMessageTemplate(savedUserMessageTemplate);
  }, []);

  const saveSettings = () => {
    localStorage.setItem('gemini-api-key', apiKey);
    localStorage.setItem('gemini-system-prompt', systemPrompt);
    localStorage.setItem('gemini-user-message-template', userMessageTemplate);
    
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 3000);
  };

  return (
    <SettingsContext.Provider
      value={{
        apiKey,
        setApiKey,
        systemPrompt,
        setSystemPrompt,
        userMessageTemplate,
        setUserMessageTemplate,
        saveSettings,
        settingsSaved
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = (): SettingsContextType => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};