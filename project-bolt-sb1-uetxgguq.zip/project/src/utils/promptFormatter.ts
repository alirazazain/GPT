/**
 * Formats a prompt template by replacing placeholders with actual content
 * @param template The prompt template with placeholders
 * @param questionContent The content to insert into the template
 * @returns Formatted prompt string
 */
export function formatPrompt(template: string, questionContent: string): string {
  return template.replace('{question}', questionContent);
}

/**
 * Generates a random ID for use in components
 * @returns A random string ID
 */
export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}