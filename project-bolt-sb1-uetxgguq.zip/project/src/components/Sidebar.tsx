import React from 'react';
import { Check, Settings, X } from 'lucide-react';

interface SidebarProps {
  activeModule: 'validate' | 'settings';
  setActiveModule: (module: 'validate' | 'settings') => void;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  activeModule, 
  setActiveModule, 
  isSidebarOpen,
  setIsSidebarOpen
}) => {
  const handleModuleChange = (module: 'validate' | 'settings') => {
    setActiveModule(module);
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  };

  return (
    <>
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black/30 z-20"
          onClick={() => setIsSidebarOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <aside 
        className={`
          fixed md:sticky top-0 left-0 h-full md:h-screen w-64 bg-white dark:bg-gray-800
          shadow-lg md:shadow-none z-30 transform transition-transform duration-300 ease-in-out
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
        `}
      >
        {/* Mobile close button */}
        <div className="md:hidden flex justify-between items-center p-4 border-b dark:border-gray-700">
          <h2 className="font-semibold text-lg">MCQ Validator</h2>
          <button
            onClick={() => setIsSidebarOpen(false)}
            className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
            aria-label="Close sidebar"
          >
            <X size={20} />
          </button>
        </div>

        {/* Logo and title - desktop */}
        <div className="hidden md:flex items-center p-6 border-b border-gray-200 dark:border-gray-700">
          <h1 className="text-xl font-bold">MCQ Validator</h1>
        </div>

        {/* Navigation links */}
        <nav className="p-4">
          <ul className="space-y-2">
            <li>
              <button
                onClick={() => handleModuleChange('validate')}
                className={`
                  w-full flex items-center px-4 py-3 rounded-lg text-left transition-colors
                  ${activeModule === 'validate'
                    ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                  }
                `}
              >
                <Check size={20} className="mr-3" />
                <span className="font-medium">Validate</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => handleModuleChange('settings')}
                className={`
                  w-full flex items-center px-4 py-3 rounded-lg text-left transition-colors
                  ${activeModule === 'settings'
                    ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                  }
                `}
              >
                <Settings size={20} className="mr-3" />
                <span className="font-medium">Settings</span>
              </button>
            </li>
          </ul>
        </nav>

        {/* Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-4 text-center text-sm text-gray-500 dark:text-gray-400">
          MCQ Validator v1.0.0
        </div>
      </aside>
    </>
  );
};

export default Sidebar;