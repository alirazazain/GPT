import React, { useState } from 'react';
import { Check, Copy, AlertCircle } from 'lucide-react';
import Card from '../components/Card';
import TextArea from '../components/TextArea';
import Button from '../components/Button';
import { useSettings } from '../context/SettingsContext';
import { validateMCQ } from '../services/geminiService';

const ValidateModule: React.FC = () => {
  const { apiKey, systemPrompt, userMessageTemplate } = useSettings();
  const [questionInput, setQuestionInput] = useState('');
  const [validationResult, setValidationResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const handleValidate = async () => {
    if (!questionInput.trim()) {
      setError('Please enter a question to validate');
      return;
    }

    if (!apiKey) {
      setError('API key is not configured. Please go to Settings and add your Gemini API key.');
      return;
    }

    setError('');
    setIsLoading(true);
    
    try {
      const result = await validateMCQ(apiKey, systemPrompt, userMessageTemplate, questionInput);
      setValidationResult(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
      setValidationResult('');
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(validationResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col space-y-2">
        <h1 className="text-2xl font-bold">Validate MCQ</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Paste your multiple-choice question below and click validate to check its correctness.
        </p>
      </div>

      <Card>
        <div className="space-y-6">
          <TextArea
            label="Question"
            placeholder="Paste your multiple-choice question here..."
            value={questionInput}
            onChange={(e) => setQuestionInput(e.target.value)}
            rows={8}
            className="font-mono text-sm"
          />

          {error && (
            <div className="flex items-center p-4 text-sm text-red-800 border border-red-300 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400 dark:border-red-800">
              <AlertCircle className="mr-2 h-5 w-5" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex justify-end">
            <Button 
              onClick={handleValidate} 
              isLoading={isLoading}
              disabled={!questionInput.trim() || !apiKey}
              icon={<Check size={18} />}
            >
              Validate
            </Button>
          </div>
        </div>
      </Card>

      {validationResult && (
        <Card className="mt-8">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Validation Result</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={copyToClipboard}
                icon={copied ? <Check size={16} /> : <Copy size={16} />}
              >
                {copied ? 'Copied!' : 'Copy'}
              </Button>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-md border border-gray-200 dark:border-gray-700">
              <pre className="whitespace-pre-wrap font-mono text-sm overflow-auto max-h-96">
                {validationResult}
              </pre>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};

export default ValidateModule;