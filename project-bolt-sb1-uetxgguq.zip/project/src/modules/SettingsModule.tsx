import React, { useState } from 'react';
import { Save, CheckCircle } from 'lucide-react';
import Card from '../components/Card';
import Input from '../components/Input';
import TextArea from '../components/TextArea';
import Button from '../components/Button';
import { useSettings } from '../context/SettingsContext';

const SettingsModule: React.FC = () => {
  const { 
    apiKey, 
    setApiKey, 
    systemPrompt, 
    setSystemPrompt, 
    userMessageTemplate, 
    setUserMessageTemplate,
    saveSettings,
    settingsSaved
  } = useSettings();

  const [isApiKeyVisible, setIsApiKeyVisible] = useState(false);

  const handleReset = () => {
    setSystemPrompt('You are a certified academic reviewer. Your task is to validate the following MCQ and determine if the answer and explanation are logically and factually correct.');
    setUserMessageTemplate('Here is the Question Block:\n\n{question}\n\nPlease validate if the marked answer is correct. If it\'s incorrect, explain why and provide the correct answer.');
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col space-y-2">
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Configure your API key and customize prompts for the validation process.
        </p>
      </div>

      <Card title="API Configuration">
        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Gemini API Key
              </label>
              <button
                type="button"
                className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                onClick={() => setIsApiKeyVisible(!isApiKeyVisible)}
              >
                {isApiKeyVisible ? 'Hide' : 'Show'}
              </button>
            </div>
            <Input
              type={isApiKeyVisible ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="Enter your Gemini API key"
              className="font-mono"
              helpText="Your API key is stored locally in your browser and never sent to our servers."
            />
          </div>

          <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex justify-end space-x-3">
              {settingsSaved && (
                <div className="flex items-center text-green-600 dark:text-green-400">
                  <CheckCircle size={16} className="mr-1" />
                  <span className="text-sm">Settings saved</span>
                </div>
              )}
              <Button 
                variant="outline" 
                onClick={handleReset}
              >
                Reset to Default
              </Button>
              <Button 
                onClick={saveSettings}
                icon={<Save size={18} />}
              >
                Save Settings
              </Button>
            </div>
          </div>
        </div>
      </Card>

      <Card title="Prompt Templates">
        <div className="space-y-6">
          <TextArea
            label="System Prompt"
            value={systemPrompt}
            onChange={(e) => setSystemPrompt(e.target.value)}
            rows={4}
            helpText="This is the instruction given to the AI model to set its behavior."
          />

          <TextArea
            label="User Message Template"
            value={userMessageTemplate}
            onChange={(e) => setUserMessageTemplate(e.target.value)}
            rows={4}
            helpText="Use {question} as a placeholder for the MCQ input. This template will be used to format the request to the API."
          />
        </div>
      </Card>
    </div>
  );
};

export default SettingsModule;